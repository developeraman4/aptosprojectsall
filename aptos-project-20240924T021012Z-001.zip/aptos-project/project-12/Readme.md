# CustomToken Smart Contract

## Vision

The **CustomToken** smart contract allows users to create, mint, and transfer custom tokens on the Aptos blockchain. With the ability to define token parameters such as name, symbol, and initial supply, this contract provides a flexible foundation for building custom cryptocurrencies or tokens within decentralized applications.

## Features

- **Create Custom Tokens**:
  - Users can create tokens with unique names, symbols, and supply specifications.
- **Minting Tokens**:
  - The contract allows minting new tokens to specified addresses, with events emitted for transparency.
- **Token Transfer**:

  - Users can transfer custom tokens to other accounts securely on-chain.

- **Balance Check**:
  - Users can check the token balance of any account.

## Future Scope

1. **Token Governance**:

   - Add governance features to manage minting, burning, and other token-related decisions through community voting.

2. **Burning Tokens**:

   - Implement token burn functionality to reduce the total supply as needed for deflationary economics.

3. **Staking Mechanism**:
   - Integrate staking features that allow users to lock tokens in return for rewards or governance privileges.

The **CustomToken** contract provides a robust platform for creating and managing tokens, empowering users to build flexible token economies within decentralized applications.
