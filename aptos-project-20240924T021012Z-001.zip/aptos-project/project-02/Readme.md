# Peer-to-Peer Loan System on Blockchain

## Vision

The **P2P Loan System** aims to revolutionize lending by providing a decentralized, transparent, and trustless environment for peer-to-peer (P2P) loans. By utilizing blockchain technology, this system ensures that loan agreements are enforced by smart contracts without the need for intermediaries like banks. Both lenders and borrowers can directly interact and execute loans with pre-defined terms, such as the amount, interest rate, and repayment period, securely and transparently.

## Features

1. **Loan Creation**:

   - Lenders can create loans by specifying the borrower's address, the loan amount, interest rate, and loan duration.
   - The system ensures the lender has sufficient funds before initiating the loan transfer.

2. **Loan Repayment**:

   - Borrowers can repay loans along with the agreed-upon interest.
   - The system calculates the total repayment based on the principal amount and the interest rate defined during loan creation.

3. **Time-based Enforcement**:

   - The contract uses blockchain timestamps to set deadlines, ensuring that loans must be repaid within the specified period.

4. **Security and Transparency**:
   - Funds are transferred automatically using smart contracts, ensuring that all parties adhere to the agreed terms.
   - The system asserts conditions like sufficient balances and existing loan contracts, ensuring security in lending and repayment.

## Smart Contract Overview

The contract includes two main functionalities:

1. **create_loan**:

   - Inputs: Lender’s signer, Borrower’s address, Loan amount, Interest rate, Loan duration.
   - Lender initiates a loan to a borrower, transferring the loan amount and storing the loan terms on-chain.
   - The loan is associated with the borrower and can be enforced by the smart contract.

2. **repay_loan**:
   - Inputs: Borrower’s signer.
   - The borrower repays the loan by transferring the original loan amount plus interest back to the lender.
   - The contract ensures that the borrower has enough funds before allowing repayment.

## Future Scope

1. **Collateralized Loans**:

   - Future versions of the contract could introduce collateral requirements, where borrowers must lock assets as collateral, reducing the lender’s risk.

2. **Credit Scoring System**:

   - A decentralized credit scoring system could be implemented, where borrowers build a reputation based on their repayment history, enabling better loan terms for trustworthy borrowers.

3. **Loan Extensions and Renegotiations**:

   - Loan terms could be extended or renegotiated based on mutual agreement between the lender and borrower, with the smart contract facilitating the adjustments.

4. **Multi-Asset Support**:

   - The system can support multiple types of coins or assets, enabling more flexible loan agreements across different cryptocurrencies.

5. **Automated Enforcement and Liquidation**:

   - Future versions could automatically penalize borrowers for overdue loans or liquidate collateral in case of non-payment.

6. **Interest Accrual over Time**:
   - Introduce functionality for interest to accrue progressively over the loan period, allowing for more complex loan agreements, such as those with compounding interest.

## Installation and Usage

### Prerequisites

- Move language development environment.
- Aptos blockchain or a compatible blockchain environment.
- Sufficient funds in the lender's account to initiate a loan.

### Steps

1. **Compile**: Compile the Move module using the Move compiler.
2. **Deploy**: Deploy the contract to a blockchain compatible with Aptos.
3. **Interact**:
   - Use `create_loan` to create a loan between a lender and a borrower.
   - Use `repay_loan` for the borrower to repay the loan.

### Example Usage

```rust
// Create a loan of 100 coins with a 5% interest rate and a duration of 30 days
create_loan<CoinType>(&lender_signer, borrower_address, 100, 5, 2592000);

// Borrower repays the loan after 30 days
repay_loan<CoinType>(&borrower_signer);
```

By leveraging blockchain, this P2P loan system eliminates the need for intermediaries, provides transparency, and ensures trustless enforcement of loan agreements. As the system evolves, it will offer more robust features, such as collateralization and credit scoring, further enhancing its usability and security in decentralized finance (DeFi) environments.
