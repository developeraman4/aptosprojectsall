# QuizGame Smart Contract

## Vision

The **QuizGame** smart contract offers a decentralized platform for users to create quiz games with token rewards for correct answers. It encourages engagement and learning by rewarding players with tokens, creating a fun and educational environment.

## Features

- **Create a Quiz**:
  - Users can create a quiz by specifying the correct answer and setting a token reward for participants who answer correctly.
- **Answer the Quiz**:
  - Players can submit answers, and if correct, they earn tokens as a reward from the quiz creator.

## Future Scope

1. **Multiple Choice Questions**:

   - Expand the quiz format to include multiple-choice questions, offering more interactive quizzes.

2. **Leaderboard**:

   - Implement a leaderboard system to track top players and reward the most successful participants.

3. **Timed Quizzes**:
   - Add time-limited quizzes where participants must answer within a set period to earn rewards.

The **QuizGame** contract promotes engagement and rewards knowledge through an interactive and rewarding quiz system on the blockchain.
