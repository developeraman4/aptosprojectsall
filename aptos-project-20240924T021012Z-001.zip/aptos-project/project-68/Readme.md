# SimplePaymentSystem Smart Contract

## Vision

The **SimplePaymentSystem** smart contract provides a straightforward and secure method for transferring tokens between users on the Aptos blockchain. It enables seamless peer-to-peer payments while offering transparency and ease of use in managing balances.

## Features

- **Send Payment**:
  - Users can send tokens to other users by specifying the recipient's address and the payment amount.
- **Check Balance**:
  - Allows users to check their current token balance, ensuring transparency over their assets.

## Future Scope

1. **Multi-Token Support**:

   - Extend the system to support multiple token types, offering flexibility in payments.

2. **Recurring Payments**:

   - Implement functionality for recurring payments, allowing users to automate regular transfers.

3. **Transaction History**:
   - Add a feature to log and display transaction histories for users, providing better financial tracking.

The **SimplePaymentSystem** contract offers a reliable, decentralized solution for basic payments, making transactions on the blockchain easy and accessible.
