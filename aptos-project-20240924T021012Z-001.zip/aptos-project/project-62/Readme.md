# DigitalGoodsRental Smart Contract

## Vision

The **DigitalGoodsRental** smart contract facilitates the decentralized rental of digital goods. It allows owners to create rental agreements, where renters can pay a fee to use the digital good for a specified duration. The contract ensures transparency and security in managing rental terms and tracking rental periods.

## Features

- **Create Rental Agreement**:
  - Digital goods owners can create a rental agreement, setting the rental fee and duration.
- **Rent Digital Good**:

  - Renters can rent the digital good by paying the rental fee, with the rental period tracked on-chain.

- **Check Rental Status**:
  - The contract includes functionality to check if a rental is still active based on the start time and duration.

## Future Scope

1. **Automated Expiry**:

   - Implement automatic handling of expired rentals, returning the digital good to the owner when the rental period ends.

2. **Extend Rental**:

   - Add functionality for renters to extend their rental duration by paying additional fees.

3. **Reputation System**:
   - Introduce a rating or reputation system for both renters and owners to ensure trust and accountability.

The **DigitalGoodsRental** contract provides a transparent and secure platform for renting digital goods, promoting fair transactions and efficient resource utilization in a decentralized manner.
